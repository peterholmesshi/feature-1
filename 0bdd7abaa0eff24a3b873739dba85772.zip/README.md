# IoTBay
Introduction To Software Development Project

The Main Branch has all the files needed for the application to run. 

In Order to run the project, download the lab folder with all the files. 
1. Open the terminal and run "mvn package"
2. run "mvn jetty:run"
3. Then in your browser go to http://localhost:8080/labs/
